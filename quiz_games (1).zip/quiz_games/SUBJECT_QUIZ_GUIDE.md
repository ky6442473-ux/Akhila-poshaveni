# Subject-Based Quiz System - Complete Implementation

## Overview
Created a comprehensive subject-based quiz system with 3 subjects:
- **General Knowledge** (30 questions, randomly 10 selected)
- **Aptitude** (30 questions, randomly 10 selected)
- **English** (30 questions, randomly 10 selected)

---

## Files Created

### 1. **questions.py** - Question Database
- Contains 30 questions for each subject
- Each question has:
  - `question`: The question text
  - `options`: List of 4 answer options
  - `correct`: Index of the correct answer (0-3)

### 2. **subject_quiz.html** - Quiz Question Template
- Clean, modern UI matching your gradient theme
- Displays one question at a time
- Shows 4 radio button options
- Progress bar at top showing question progress
- "Next Question" or "Submit Quiz" button
- Session tracking for answers

### 3. **subject_result.html** - Results Template
- Shows total score (correct/total)
- Percentage and feedback message
- Summary stats (correct/wrong count)
- Detailed review of all answers with:
  - User's answer
  - Correct answer (if wrong)
  - Visual indicators (✓ Correct / ✗ Incorrect)
- Buttons to retake, choose different subject, or go home

### 4. **results.css** - Results Page Styling
- Beautiful result card design
- Score display with large numbers
- Summary statistics boxes
- Detailed answer review with color coding
- Responsive design for all devices

### 5. **Updated subjects.html**
- Changed button links to use `start_subject_quiz` view
- Each subject button now initiates proper quiz flow

---

## Django Views Created

### **start_subject_quiz(request, subject)**
- Requires authentication
- Selects subject based on parameter (general_knowledge, aptitude, english)
- Randomly chooses 10 questions from the question bank
- Stores in session:
  - `{subject}_quiz_questions`: Selected questions
  - `{subject}_current_question`: Current index (0)
  - `{subject}_answers`: Dictionary for storing answers
  - `{subject}_subject_name`: Subject display name
- Redirects to `subject_quiz` view

### **subject_quiz(request, subject)**
- Displays current question
- Handles POST requests with user's selected answer
- Stores answer with metadata:
  - Question text
  - User's answer
  - Correct answer
  - Whether it's correct
- Increments question index
- Redirects to next question or result page

### **subject_result(request, subject)**
- Calculates score (correct/wrong/total/percentage)
- Displays detailed results with answer review
- Renders `subject_result.html`

---

## Session Management

The system uses Django sessions to track:

```
{subject}_quiz_questions      → List of 10 selected questions
{subject}_current_question    → Current question index (0-9)
{subject}_answers             → Dict of user answers with details
{subject}_subject_name        → Display name of subject
```

**Example Session Structure:**
```python
{
    'general_knowledge_quiz_questions': [
        {'question': '...', 'options': [...], 'correct': 2},
        ...
    ],
    'general_knowledge_current_question': 5,
    'general_knowledge_answers': {
        '0': {
            'question': 'What is the capital of France?',
            'options': ['London', 'Berlin', 'Paris', 'Madrid'],
            'user_answer': 'Paris',
            'correct_answer': 'Paris',
            'correct_index': 2,
            'is_correct': True
        },
        ...
    },
    'general_knowledge_subject_name': 'General Knowledge'
}
```

---

## URL Routes

```
/subjects/                              → Choose subject (subjects.html)
/quiz/general_knowledge/start/          → Start GK quiz
/quiz/general_knowledge/                → GK quiz questions
/result/general_knowledge/              → GK results
/quiz/aptitude/start/                   → Start Aptitude quiz
/quiz/aptitude/                         → Aptitude quiz questions
/result/aptitude/                       → Aptitude results
/quiz/english/start/                    → Start English quiz
/quiz/english/                          → English quiz questions
/result/english/                        → English results
```

---

## Quiz Flow

1. **User Login** → Home Page
2. **Click "Start Quiz"** → Subjects Selection Page
3. **Select Subject** → Initializes quiz session
4. **Answer Questions** → One-by-one, 10 total
5. **Submit Quiz** → View detailed results
6. **Review Answers** → See correct/incorrect with explanations
7. **Options:**
   - **Retake Quiz** → Same subject, new random questions
   - **Different Subject** → Back to subjects page
   - **Home** → Back to home page

---

## Features Implemented

✅ **Random Question Selection** - 10 random questions from 30 per subject
✅ **Session Tracking** - Maintains current question index and answers
✅ **One Question at a Time** - Clean UX with progress bar
✅ **Answer Storage** - Stores user answer with correct answer
✅ **Detailed Results** - Shows all answers with visual feedback
✅ **Responsive Design** - Works on all devices
✅ **Authentication Required** - Only logged-in users can take quiz
✅ **Multiple Retakes** - Users can retake quizzes with different questions
✅ **Visual Feedback** - Color-coded correct/incorrect answers
✅ **Progress Tracking** - Progress bar shows quiz completion

---

## Testing the Quiz

1. **Login/Signup** at `/login/` or `/signup/`
2. **Go to Home** and click "Start Quiz"
3. **Select a Subject** (General Knowledge, Aptitude, or English)
4. **Answer 10 Questions** one by one
5. **Submit Quiz** to see your results
6. **Review Answers** with correct/incorrect feedback
7. **Retake or Choose Different Subject**

---

## Question Banks

Each subject contains 30 well-crafted questions:

### General Knowledge (30 questions)
- Geography, history, science, space, nature topics
- Examples: Capital cities, planet facts, historical events, scientists

### Aptitude (30 questions)
- Math, logic, reasoning, problem-solving
- Examples: Arithmetic, percentages, equations, sequences, patterns

### English (30 questions)
- Grammar, vocabulary, spelling, comprehension
- Examples: Sentence correction, synonyms/antonyms, spelling, word meanings

---

## Customization

To add more questions, edit `questions.py`:

```python
GENERAL_KNOWLEDGE_QUESTIONS = [
    {
        'question': 'Your question here?',
        'options': ['Option 1', 'Option 2', 'Option 3', 'Option 4'],
        'correct': 1  # Index of correct answer (0-3)
    },
    ...
]
```

To change number of questions per quiz, modify in `start_subject_quiz()`:
```python
selected_questions = random.sample(all_questions, min(15, len(all_questions)))  # Change 10 to 15
```
