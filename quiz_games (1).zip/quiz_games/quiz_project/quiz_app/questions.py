# Quiz Questions Data for all subjects

GENERAL_KNOWLEDGE_QUESTIONS = [
    {
        'question': 'What is the capital of France?',
        'options': ['London', 'Berlin', 'Paris', 'Madrid'],
        'correct': 2
    },
    {
        'question': 'Which planet is known as the Red Planet?',
        'options': ['Venus', 'Mars', 'Jupiter', 'Saturn'],
        'correct': 1
    },
    {
        'question': 'Who wrote the theory of relativity?',
        'options': ['Isaac Newton', 'Albert Einstein', 'Galileo Galilei', 'Stephen Hawking'],
        'correct': 1
    },
    {
        'question': 'What is the smallest country in the world by area?',
        'options': ['Monaco', 'Vatican City', 'San Marino', 'Liechtenstein'],
        'correct': 1
    },
    {
        'question': 'Which ocean is the largest?',
        'options': ['Atlantic Ocean', 'Indian Ocean', 'Arctic Ocean', 'Pacific Ocean'],
        'correct': 3
    },
    {
        'question': 'In what year did the Titanic sink?',
        'options': ['1912', '1915', '1920', '1905'],
        'correct': 0
    },
    {
        'question': 'Who painted the Mona Lisa?',
        'options': ['Michelangelo', 'Leonardo da Vinci', 'Raphael', 'Donatello'],
        'correct': 1
    },
    {
        'question': 'What is the longest river in the world?',
        'options': ['Amazon River', 'Nile River', 'Yangtze River', 'Mississippi River'],
        'correct': 1
    },
    {
        'question': 'Which country is home to the kangaroo?',
        'options': ['New Zealand', 'Australia', 'South Africa', 'Brazil'],
        'correct': 1
    },
    {
        'question': 'What is the capital of Japan?',
        'options': ['Osaka', 'Kyoto', 'Tokyo', 'Yokohama'],
        'correct': 2
    },
    {
        'question': 'Who was the first President of the United States?',
        'options': ['Thomas Jefferson', 'George Washington', 'John Adams', 'Benjamin Franklin'],
        'correct': 1
    },
    {
        'question': 'What is the chemical symbol for Gold?',
        'options': ['Go', 'Gd', 'Au', 'Ag'],
        'correct': 2
    },
    {
        'question': 'In which country is the Great Wall located?',
        'options': ['Japan', 'Vietnam', 'China', 'Korea'],
        'correct': 2
    },
    {
        'question': 'What is the largest mammal in the world?',
        'options': ['African Elephant', 'Blue Whale', 'Giraffe', 'Hippopotamus'],
        'correct': 1
    },
    {
        'question': 'How many continents are there?',
        'options': ['5', '6', '7', '8'],
        'correct': 2
    },
    {
        'question': 'What is the capital of India?',
        'options': ['Mumbai', 'Delhi', 'Bangalore', 'Chennai'],
        'correct': 1
    },
    {
        'question': 'Which is the hottest planet in our solar system?',
        'options': ['Mercury', 'Venus', 'Earth', 'Mars'],
        'correct': 1
    },
    {
        'question': 'Who invented the telephone?',
        'options': ['Thomas Edison', 'Alexander Graham Bell', 'Nikola Tesla', 'Michael Faraday'],
        'correct': 1
    },
    {
        'question': 'What is the currency of the United Kingdom?',
        'options': ['Euro', 'Dollar', 'Pound Sterling', 'Franc'],
        'correct': 2
    },
    {
        'question': 'Which element has the atomic number 1?',
        'options': ['Helium', 'Hydrogen', 'Lithium', 'Beryllium'],
        'correct': 1
    },
    {
        'question': 'What year did World War II end?',
        'options': ['1943', '1944', '1945', '1946'],
        'correct': 2
    },
    {
        'question': 'Who was the first man to walk on the moon?',
        'options': ['Buzz Aldrin', 'Neil Armstrong', 'Yuri Gagarin', 'John Glenn'],
        'correct': 1
    },
    {
        'question': 'What is the capital of Brazil?',
        'options': ['Rio de Janeiro', 'Brasília', 'São Paulo', 'Salvador'],
        'correct': 1
    },
    {
        'question': 'How many strings does a violin have?',
        'options': ['4', '5', '6', '7'],
        'correct': 0
    },
    {
        'question': 'Which country has the most population?',
        'options': ['India', 'China', 'USA', 'Indonesia'],
        'correct': 1
    },
    {
        'question': 'What is the smallest bone in the human body?',
        'options': ['Femur', 'Stapes', 'Radius', 'Tibia'],
        'correct': 1
    },
    {
        'question': 'Which gas do plants absorb from the atmosphere?',
        'options': ['Oxygen', 'Nitrogen', 'Carbon Dioxide', 'Hydrogen'],
        'correct': 2
    },
    {
        'question': 'What is the speed of light?',
        'options': ['300,000 km/s', '150,000 km/s', '450,000 km/s', '600,000 km/s'],
        'correct': 0
    },
    {
        'question': 'Who wrote "Romeo and Juliet"?',
        'options': ['Christopher Marlowe', 'William Shakespeare', 'Ben Jonson', 'Edmund Spenser'],
        'correct': 1
    },
    {
        'question': 'What is the tallest mountain in the world?',
        'options': ['K2', 'Mount Everest', 'Kangchenjunga', 'Makalu'],
        'correct': 1
    },
]

APTITUDE_QUESTIONS = [
    {
        'question': 'If a train travels 60 km/h for 2 hours, what distance does it cover?',
        'options': ['60 km', '120 km', '180 km', '240 km'],
        'correct': 1
    },
    {
        'question': 'What is 15% of 200?',
        'options': ['15', '20', '30', '40'],
        'correct': 2
    },
    {
        'question': 'If x + 5 = 12, what is the value of x?',
        'options': ['5', '6', '7', '8'],
        'correct': 2
    },
    {
        'question': 'What is the next number in the sequence: 2, 4, 8, 16, ?',
        'options': ['24', '28', '32', '36'],
        'correct': 2
    },
    {
        'question': 'If A can do a job in 5 days and B can do it in 10 days, how long will it take them together?',
        'options': ['3.33 days', '3.67 days', '4.33 days', '4.67 days'],
        'correct': 0
    },
    {
        'question': 'What is 20% of 150?',
        'options': ['20', '25', '30', '35'],
        'correct': 2
    },
    {
        'question': 'If 2x + 3 = 11, what is x?',
        'options': ['3', '4', '5', '6'],
        'correct': 1
    },
    {
        'question': 'Find the missing number: 5, 10, 20, 40, ?',
        'options': ['60', '70', '80', '100'],
        'correct': 2
    },
    {
        'question': 'What is the average of 10, 20, 30, 40?',
        'options': ['20', '25', '30', '35'],
        'correct': 1
    },
    {
        'question': 'If a book costs $15 and is on sale for 25% off, what is the new price?',
        'options': ['$10', '$11.25', '$12', '$13.50'],
        'correct': 1
    },
    {
        'question': 'What is 3² + 4²?',
        'options': ['12', '14', '25', '49'],
        'correct': 2
    },
    {
        'question': 'If 30% of x is 60, what is x?',
        'options': ['100', '150', '200', '250'],
        'correct': 1
    },
    {
        'question': 'What is the median of 5, 10, 15, 20, 25?',
        'options': ['10', '15', '20', '25'],
        'correct': 1
    },
    {
        'question': 'If a rectangle has length 8 and width 5, what is its area?',
        'options': ['13', '26', '40', '80'],
        'correct': 2
    },
    {
        'question': 'What is the square root of 144?',
        'options': ['10', '11', '12', '13'],
        'correct': 2
    },
    {
        'question': 'If you buy 3 items at $5 each with a 10% discount, what do you pay?',
        'options': ['$13.50', '$14.50', '$15', '$15.50'],
        'correct': 0
    },
    {
        'question': 'What is 25 × 4 ÷ 5?',
        'options': ['10', '15', '20', '25'],
        'correct': 2
    },
    {
        'question': 'If a car travels 300 km in 5 hours, what is its average speed?',
        'options': ['50 km/h', '60 km/h', '70 km/h', '80 km/h'],
        'correct': 1
    },
    {
        'question': 'What is the next number: 1, 1, 2, 3, 5, 8, ?',
        'options': ['10', '12', '13', '15'],
        'correct': 2
    },
    {
        'question': 'If x - 8 = 3, what is x?',
        'options': ['5', '10', '11', '15'],
        'correct': 2
    },
    {
        'question': 'What is 10% of 500?',
        'options': ['25', '50', '75', '100'],
        'correct': 1
    },
    {
        'question': 'If a circle has radius 5, what is its area? (use π ≈ 3.14)',
        'options': ['31.4', '47.1', '78.5', '314'],
        'correct': 2
    },
    {
        'question': 'What is the mode of 2, 3, 3, 4, 5, 5, 5?',
        'options': ['3', '4', '5', '2'],
        'correct': 2
    },
    {
        'question': 'If 5x = 25, what is x?',
        'options': ['3', '4', '5', '6'],
        'correct': 2
    },
    {
        'question': 'What is 15 + 25 - 10?',
        'options': ['20', '25', '30', '35'],
        'correct': 2
    },
    {
        'question': 'If a worker earns $200 per week, how much does he earn in 4 weeks?',
        'options': ['$600', '$700', '$800', '$900'],
        'correct': 2
    },
    {
        'question': 'What is the next even number after 48?',
        'options': ['49', '50', '51', '52'],
        'correct': 1
    },
    {
        'question': 'If 2 pens cost $4, how much do 5 pens cost?',
        'options': ['$8', '$9', '$10', '$12'],
        'correct': 2
    },
    {
        'question': 'What is 12 × 11?',
        'options': ['120', '130', '132', '144'],
        'correct': 2
    },
    {
        'question': 'If a number is multiplied by 3 and then 6 is subtracted, the result is 12. What is the number?',
        'options': ['4', '5', '6', '7'],
        'correct': 1
    },
]

ENGLISH_QUESTIONS = [
    {
        'question': 'Choose the correct spelling:',
        'options': ['Ocassion', 'Ocasion', 'Occasion', 'Occassion'],
        'correct': 2
    },
    {
        'question': 'What is the synonym of "Bright"?',
        'options': ['Dark', 'Luminous', 'Dim', 'Dull'],
        'correct': 1
    },
    {
        'question': 'Choose the correct grammar: "She ___ to the store yesterday."',
        'options': ['goes', 'go', 'went', 'going'],
        'correct': 2
    },
    {
        'question': 'What is the antonym of "Happy"?',
        'options': ['Joyful', 'Cheerful', 'Sad', 'Excited'],
        'correct': 2
    },
    {
        'question': 'Choose the correct form: "I ___ been here before."',
        'options': ['have', 'has', 'had', 'having'],
        'correct': 0
    },
    {
        'question': 'What does "Ephemeral" mean?',
        'options': ['Permanent', 'Temporary', 'Eternal', 'Ancient'],
        'correct': 1
    },
    {
        'question': 'Choose the correct spelling:',
        'options': ['Recieve', 'Receive', 'Recieve', 'Receieve'],
        'correct': 1
    },
    {
        'question': 'What is the meaning of "Pragmatic"?',
        'options': ['Emotional', 'Practical and realistic', 'Theoretical', 'Idealistic'],
        'correct': 1
    },
    {
        'question': 'Which sentence is grammatically correct?',
        'options': ['She don\'t like apples', 'She doesn\'t like apples', 'She do not like apples', 'She has not like apples'],
        'correct': 1
    },
    {
        'question': 'What is the synonym of "Benevolent"?',
        'options': ['Cruel', 'Kind', 'Selfish', 'Rude'],
        'correct': 1
    },
    {
        'question': 'Choose the correct form: "If I ___ you were coming, I would have prepared."',
        'options': ['knew', 'know', 'known', 'had knew'],
        'correct': 0
    },
    {
        'question': 'What does "Eloquent" mean?',
        'options': ['Silent', 'Fluent and expressive in speech', 'Boring', 'Unclear'],
        'correct': 1
    },
    {
        'question': 'Choose the correct spelling:',
        'options': ['Definately', 'Definately', 'Definitely', 'Definitly'],
        'correct': 2
    },
    {
        'question': 'What is the antonym of "Abundance"?',
        'options': ['Plenty', 'Scarcity', 'Wealth', 'Prosperity'],
        'correct': 1
    },
    {
        'question': 'Which is correct: "There are many students in the class" or "There is many students in the class"?',
        'options': ['Second one', 'First one', 'Both are correct', 'Neither is correct'],
        'correct': 1
    },
    {
        'question': 'What does "Diligent" mean?',
        'options': ['Lazy', 'Hardworking', 'Careless', 'Inactive'],
        'correct': 1
    },
    {
        'question': 'Choose the correct form: "___ you finished your homework?"',
        'options': ['Do', 'Have', 'Did', 'Will'],
        'correct': 2
    },
    {
        'question': 'What is the meaning of "Ambiguous"?',
        'options': ['Clear', 'Open-minded', 'Unclear or having more than one meaning', 'Certain'],
        'correct': 2
    },
    {
        'question': 'Choose the correct spelling:',
        'options': ['Seperate', 'Separate', 'Seperete', 'Seperete'],
        'correct': 1
    },
    {
        'question': 'What is the synonym of "Meager"?',
        'options': ['Abundant', 'Scarce', 'Plentiful', 'Rich'],
        'correct': 1
    },
    {
        'question': 'Which sentence is correct?',
        'options': ['She is taller than him', 'She is more taller than him', 'She is tallest than him', 'She is tall than him'],
        'correct': 0
    },
    {
        'question': 'What does "Nostalgia" mean?',
        'options': ['Fear of future', 'Sentimental longing for the past', 'Hatred', 'Love'],
        'correct': 1
    },
    {
        'question': 'Choose the correct form: "The book ___ on the table."',
        'options': ['lie', 'lays', 'lies', 'laying'],
        'correct': 2
    },
    {
        'question': 'What is the antonym of "Fragile"?',
        'options': ['Weak', 'Delicate', 'Strong', 'Tender'],
        'correct': 2
    },
    {
        'question': 'Which word is spelled correctly?',
        'options': ['Acheive', 'Achieve', 'Acheve', 'Acheeve'],
        'correct': 1
    },
    {
        'question': 'What does "Succinct" mean?',
        'options': ['Long', 'Concise', 'Detailed', 'Complex'],
        'correct': 1
    },
    {
        'question': 'Choose the correct form: "Neither of them ___ ready."',
        'options': ['are', 'is', 'am', 'be'],
        'correct': 1
    },
    {
        'question': 'What is the meaning of "Cynical"?',
        'options': ['Hopeful', 'Distrusting human sincerity', 'Optimistic', 'Trusting'],
        'correct': 1
    },
    {
        'question': 'Which sentence has correct punctuation?',
        'options': ['Whats your name', 'What\'s your name?', 'Whats your name?', 'What is your name.'],
        'correct': 1
    },
    {
        'question': 'What is the synonym of "Verbose"?',
        'options': ['Quiet', 'Wordy', 'Silent', 'Concise'],
        'correct': 1
    },
]
