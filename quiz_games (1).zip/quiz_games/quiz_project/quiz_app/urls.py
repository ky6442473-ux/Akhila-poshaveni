"""
URL configuration for quiz_app application.

URL patterns for quiz game pages:
- / : Home page
- subjects/ : Subjects selection page
- quiz/<subject>/ : Subject-based quiz
- result/<subject>/ : Subject-based result
- login/ : User login page
- signup/ : User signup page
- logout/ : User logout
"""
from django.urls import path
from quiz_app import views

urlpatterns = [
    # Home page - root URL
    path('', views.home, name='home'),
    
    # Subjects selection page
    path('subjects/', views.subjects, name='subjects'),
    
    # Subject-based quiz routes
    path('quiz/<str:subject>/start/', views.start_subject_quiz, name='start_subject_quiz'),
    path('quiz/<str:subject>/', views.subject_quiz, name='subject_quiz'),
    path('result/<str:subject>/', views.subject_result, name='subject_result'),
    
    # Old quiz routes (kept for backward compatibility)
    path('start/', views.start_quiz, name='start_quiz'),
    path('quiz/', views.quiz, name='quiz'),
    path('result/', views.result, name='result'),
    path('clear/', views.clear_session, name='clear_session'),
    
    # Authentication URLs
    path('login/', views.login_view, name='login'),
    path('signup/', views.signup_view, name='signup'),
    path('logout/', views.logout_view, name='logout'),
]
