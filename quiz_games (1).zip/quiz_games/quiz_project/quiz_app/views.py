from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from django.utils import timezone
from django.db.models import Q
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib import messages
import random
from .models import Quiz, Question, QuizSession, Answer


def home(request):
    """
    Display the home page
    """
    return render(request, 'home.html')


def subjects(request):
    """
    Display the subjects selection page
    """
    if not request.user.is_authenticated:
        return redirect('login')
    return render(request, 'subjects.html')


def start_quiz(request):
    """
    Initialize a new quiz session and redirect to first question
    """
    # Get the first quiz (or create one if needed for testing)
    quiz = Quiz.objects.first()
    
    if not quiz:
        # Create a default quiz if none exists
        quiz = Quiz.objects.create(
            title="General Knowledge Quiz",
            description="Test your general knowledge"
        )
    
    # Create a new quiz session
    session_key = request.session.session_key
    if not session_key:
        request.session.create()
        session_key = request.session.session_key
    
    quiz_session = QuizSession.objects.create(
        quiz=quiz,
        session_key=session_key,
        total_questions=quiz.questions.count()
    )
    
    # Store session ID in request session
    request.session['quiz_session_id'] = quiz_session.id
    request.session['current_question'] = 1
    
    return redirect('quiz')


def quiz(request):
    """
    Display the current quiz question
    """
    # Get the current quiz session
    quiz_session_id = request.session.get('quiz_session_id')
    
    if not quiz_session_id:
        return redirect('home')
    
    try:
        quiz_session = QuizSession.objects.get(id=quiz_session_id)
    except QuizSession.DoesNotExist:
        return redirect('home')
    
    quiz = quiz_session.quiz
    current_question_num = request.session.get('current_question', 1)
    
    # Get all questions (randomly ordered)
    questions = list(quiz.questions.all())
    
    if not questions:
        return redirect('result')
    
    # Ensure we have a consistent question order for this session
    if 'question_order' not in request.session:
        random.shuffle(questions)
        request.session['question_order'] = [q.id for q in questions]
    else:
        question_ids = request.session['question_order']
        questions = [Question.objects.get(id=qid) for qid in question_ids]
    
    total_questions = len(questions)
    
    # Check if all questions are answered
    if current_question_num > total_questions:
        return redirect('result')
    
    # Get current question (1-indexed to 0-indexed)
    current_question = questions[current_question_num - 1]
    options = current_question.get_options()
    
    # Calculate progress percentage
    progress = (current_question_num / total_questions) * 100
    
    context = {
        'question': current_question.question_text,
        'options': options,
        'question_number': current_question_num,
        'total_questions': total_questions,
        'progress': progress,
    }
    
    if request.method == 'POST':
        selected_option = request.POST.get('selected_option')
        
        if selected_option:
            # Check if answer is correct
            correct_answer = current_question.get_correct_answer()
            is_correct = selected_option == correct_answer
            
            # Save the answer
            Answer.objects.create(
                session=quiz_session,
                question=current_question,
                selected_option=selected_option,
                is_correct=is_correct
            )
            
            # Update score if correct
            if is_correct:
                quiz_session.score += 1
                quiz_session.save()
            
            # Move to next question
            request.session['current_question'] = current_question_num + 1
            
            # Check if quiz is complete
            if current_question_num >= total_questions:
                quiz_session.completed_at = timezone.now()
                quiz_session.save()
                return redirect('result')
            
            return redirect('quiz')
    
    return render(request, 'quiz.html', context)


def result(request):
    """
    Display quiz results
    """
    # Get the current quiz session
    quiz_session_id = request.session.get('quiz_session_id')
    
    if not quiz_session_id:
        return redirect('home')
    
    try:
        quiz_session = QuizSession.objects.get(id=quiz_session_id)
    except QuizSession.DoesNotExist:
        return redirect('home')
    
    # Calculate score percentage
    percentage = (quiz_session.score / quiz_session.total_questions * 100) if quiz_session.total_questions > 0 else 0
    
    context = {
        'score': quiz_session.score,
        'total_questions': quiz_session.total_questions,
        'percentage': percentage,
    }
    
    return render(request, 'result.html', context)


def clear_session(request):
    """
    Clear quiz session and redirect to home
    """
    # Clear session variables
    request.session.pop('quiz_session_id', None)
    request.session.pop('current_question', None)
    request.session.pop('question_order', None)
    
    return redirect('home')


# ===================================
# AUTHENTICATION VIEWS
# ===================================

def login_view(request):
    """
    Handle user login
    """
    if request.user.is_authenticated:
        return redirect('home')
    
    if request.method == 'POST':
        email = request.POST.get('email', '').strip()
        password = request.POST.get('password', '').strip()
        
        # Try to authenticate with email
        try:
            user = User.objects.get(email=email)
            user = authenticate(request, username=user.username, password=password)
            
            if user is not None:
                login(request, user)
                messages.success(request, f'Welcome back, {user.first_name or user.username}!')
                return redirect('home')
            else:
                messages.error(request, 'Invalid email or password.')
        except User.DoesNotExist:
            messages.error(request, 'Invalid email or password.')
    
    return render(request, 'login.html')


def signup_view(request):
    """
    Handle user registration
    """
    if request.user.is_authenticated:
        return redirect('home')
    
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()
        email = request.POST.get('email', '').strip()
        password = request.POST.get('password', '').strip()
        confirm_password = request.POST.get('confirm_password', '').strip()
        
        # Validate inputs
        if not all([name, email, password, confirm_password]):
            messages.error(request, 'All fields are required.')
            return render(request, 'signup.html')
        
        if password != confirm_password:
            messages.error(request, 'Passwords do not match.')
            return render(request, 'signup.html')
        
        if len(password) < 8:
            messages.error(request, 'Password must be at least 8 characters.')
            return render(request, 'signup.html')
        
        # Check if email already exists
        if User.objects.filter(email=email).exists():
            messages.error(request, 'Email already registered. Please login or use a different email.')
            return render(request, 'signup.html')
        
        # Create new user
        try:
            # Split name into first and last name
            name_parts = name.split(' ', 1)
            first_name = name_parts[0]
            last_name = name_parts[1] if len(name_parts) > 1 else ''
            
            # Username is email-based
            username = email.split('@')[0]
            
            # Handle duplicate usernames
            username_count = 1
            original_username = username
            while User.objects.filter(username=username).exists():
                username = f"{original_username}{username_count}"
                username_count += 1
            
            user = User.objects.create_user(
                username=username,
                email=email,
                password=password,
                first_name=first_name,
                last_name=last_name
            )
            
            # Log the user in
            user = authenticate(request, username=username, password=password)
            login(request, user)
            
            messages.success(request, f'Welcome {first_name}! Your account has been created.')
            return redirect('home')
            
        except Exception as e:
            messages.error(request, f'Error creating account: {str(e)}')
            return render(request, 'signup.html')
    
    return render(request, 'signup.html')


def logout_view(request):
    """
    Handle user logout
    """
    logout(request)
    messages.success(request, 'You have been logged out.')
    return redirect('home')


# ===================================
# SUBJECT-BASED QUIZ VIEWS
# ===================================

from .questions import GENERAL_KNOWLEDGE_QUESTIONS, APTITUDE_QUESTIONS, ENGLISH_QUESTIONS


def start_subject_quiz(request, subject):
    """
    Initialize a new subject-based quiz
    """
    if not request.user.is_authenticated:
        return redirect('login')
    
    # Select questions based on subject
    if subject == 'general_knowledge':
        all_questions = GENERAL_KNOWLEDGE_QUESTIONS
        subject_name = 'General Knowledge'
    elif subject == 'aptitude':
        all_questions = APTITUDE_QUESTIONS
        subject_name = 'Aptitude'
    elif subject == 'english':
        all_questions = ENGLISH_QUESTIONS
        subject_name = 'English'
    else:
        return redirect('subjects')
    
    # Randomly select 10 questions
    selected_questions = random.sample(all_questions, min(10, len(all_questions)))
    
    # Store in session
    request.session[f'{subject}_quiz_questions'] = selected_questions
    request.session[f'{subject}_current_question'] = 0
    request.session[f'{subject}_answers'] = {}
    request.session[f'{subject}_subject_name'] = subject_name
    
    return redirect('subject_quiz', subject=subject)


def subject_quiz(request, subject):
    """
    Display quiz question for a specific subject
    """
    if not request.user.is_authenticated:
        return redirect('login')
    
    # Get questions from session
    questions_key = f'{subject}_quiz_questions'
    current_key = f'{subject}_current_question'
    answers_key = f'{subject}_answers'
    subject_name_key = f'{subject}_subject_name'
    
    if questions_key not in request.session:
        return redirect('subjects')
    
    questions = request.session.get(questions_key)
    current_index = request.session.get(current_key, 0)
    answers = request.session.get(answers_key, {})
    subject_name = request.session.get(subject_name_key, '')
    
    # Check if quiz is complete
    if current_index >= len(questions):
        return redirect('subject_result', subject=subject)
    
    # Handle form submission
    if request.method == 'POST':
        selected_answer = request.POST.get('selected_option')
        
        if selected_answer:
            # Store answer
            answers[str(current_index)] = {
                'question': questions[current_index]['question'],
                'options': questions[current_index]['options'],
                'user_answer': selected_answer,
                'correct_answer': questions[current_index]['options'][questions[current_index]['correct']],
                'correct_index': questions[current_index]['correct'],
                'is_correct': selected_answer == questions[current_index]['options'][questions[current_index]['correct']]
            }
            
            request.session[answers_key] = answers
            request.session[current_key] = current_index + 1
            
            # Move to next question or result
            if current_index + 1 >= len(questions):
                return redirect('subject_result', subject=subject)
            
            return redirect('subject_quiz', subject=subject)
    
    # Get current question
    current_question = questions[current_index]
    total_questions = len(questions)
    progress = ((current_index) / total_questions) * 100
    
    context = {
        'question': current_question['question'],
        'options': current_question['options'],
        'question_number': current_index + 1,
        'total_questions': total_questions,
        'progress': progress,
        'subject': subject,
        'subject_name': subject_name,
    }
    
    return render(request, 'subject_quiz.html', context)


def subject_result(request, subject):
    """
    Display results for subject-based quiz
    """
    if not request.user.is_authenticated:
        return redirect('login')
    
    answers_key = f'{subject}_answers'
    questions_key = f'{subject}_quiz_questions'
    subject_name_key = f'{subject}_subject_name'
    
    if answers_key not in request.session:
        return redirect('subjects')
    
    answers = request.session.get(answers_key, {})
    subject_name = request.session.get(subject_name_key, '')
    
    # Calculate score
    correct_count = sum(1 for ans in answers.values() if ans['is_correct'])
    wrong_count = len(answers) - correct_count
    total = len(answers)
    percentage = (correct_count / total * 100) if total > 0 else 0
    
    # Prepare detailed results
    results = []
    for idx in sorted(answers.keys(), key=lambda x: int(x)):
        results.append(answers[idx])
    
    context = {
        'subject_name': subject_name,
        'correct_count': correct_count,
        'wrong_count': wrong_count,
        'total_questions': total,
        'percentage': percentage,
        'results': results,
        'subject': subject,
    }
    
    return render(request, 'subject_result.html', context)