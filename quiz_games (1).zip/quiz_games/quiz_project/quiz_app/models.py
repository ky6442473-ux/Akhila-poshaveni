from django.db import models


class Quiz(models.Model):
    """Quiz model to store quiz information"""
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

    class Meta:
        verbose_name_plural = "Quizzes"


class Question(models.Model):
    """Question model to store individual questions"""
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE, related_name='questions')
    question_text = models.TextField()
    option_a = models.CharField(max_length=200)
    option_b = models.CharField(max_length=200)
    option_c = models.CharField(max_length=200)
    option_d = models.CharField(max_length=200)
    correct_option = models.CharField(max_length=1, choices=[('A', 'A'), ('B', 'B'), ('C', 'C'), ('D', 'D')])
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.question_text[:50]

    def get_options(self):
        """Return options as a list"""
        return [self.option_a, self.option_b, self.option_c, self.option_d]

    def get_correct_answer(self):
        """Get the correct answer text"""
        options = {'A': self.option_a, 'B': self.option_b, 'C': self.option_c, 'D': self.option_d}
        return options[self.correct_option]


class QuizSession(models.Model):
    """Store user's quiz session and answers"""
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE)
    session_key = models.CharField(max_length=100)
    score = models.IntegerField(default=0)
    total_questions = models.IntegerField(default=0)
    started_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.quiz.title} - {self.session_key}"


class Answer(models.Model):
    """Store user answers to questions"""
    session = models.ForeignKey(QuizSession, on_delete=models.CASCADE, related_name='answers')
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    selected_option = models.CharField(max_length=200)
    is_correct = models.BooleanField(default=False)
    answered_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.session.session_key} - Q{self.question.id}"
