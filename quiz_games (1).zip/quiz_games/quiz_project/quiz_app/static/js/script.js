/* ===================================
   QUIZ GAME - JAVASCRIPT INTERACTIONS
   =================================== */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize quiz page interactivity
    initializeQuizPage();
    // Update progress bar on page load
    updateProgressBarFromServer();
});

/* ===================================
   QUIZ PAGE INITIALIZATION
   =================================== */

function initializeQuizPage() {
    const optionLabels = document.querySelectorAll('.option-label');
    const quizForm = document.getElementById('quizForm');

    // Add event listeners to each option
    optionLabels.forEach(label => {
        label.addEventListener('click', function() {
            // Remove 'selected' class from all options
            optionLabels.forEach(opt => opt.classList.remove('selected'));
            
            // Add 'selected' class to clicked option
            this.classList.add('selected');
        });

        // Also handle radio input change
        const input = label.querySelector('.option-input');
        input.addEventListener('change', function() {
            optionLabels.forEach(opt => opt.classList.remove('selected'));
            label.classList.add('selected');
        });
    });

    // Validate form before submission
    if (quizForm) {
        quizForm.addEventListener('submit', function(e) {
            const selectedOption = document.querySelector('input[name="selected_option"]:checked');
            
            if (!selectedOption) {
                e.preventDefault();
                showAlert('Please select an option before proceeding!');
            }
        });
    }
}

/* ===================================
   UTILITY FUNCTIONS
   =================================== */

/**
 * Show a simple alert to the user
 * @param {string} message - The message to display
 */
function showAlert(message) {
    // Use browser's alert (simple approach)
    // You can replace this with a custom modal if desired
    alert(message);
}

/**
 * Update progress bar based on server data
 * Reads question_number and total_questions from page
 */
function updateProgressBarFromServer() {
    const counterText = document.querySelector('.question-counter');
    if (!counterText) return;
    
    // Parse "Question X / Total" format
    const match = counterText.textContent.match(/Question\s+(\d+)\s+\/\s+(\d+)/);
    if (match) {
        const current = parseInt(match[1]);
        const total = parseInt(match[2]);
        const percentage = (current / total) * 100;
        updateProgressBar(current, total);
    }
}

/**
 * Add smooth scroll animation when page loads
 */
function animatePageLoad() {
    const card = document.querySelector('.card');
    if (card) {
        card.style.animation = 'slideUp 0.5s ease-out';
    }
}

/**
 * Update progress bar based on current question
 * @param {number} current - Current question number
 * @param {number} total - Total number of questions
 */
function updateProgressBar(current, total) {
    const progressBar = document.querySelector('.progress-bar');
    if (progressBar) {
        const percentage = (current / total) * 100;
        progressBar.style.width = percentage + '%';
    }
}

/* ===================================
   KEYBOARD NAVIGATION (OPTIONAL)
   =================================== */

document.addEventListener('keydown', function(e) {
    // Allow number keys (1-4) to select options quickly
    const key = parseInt(e.key);
    
    if (key >= 1 && key <= 4) {
        const options = document.querySelectorAll('.option-input');
        if (options[key - 1]) {
            options[key - 1].click();
            // Scroll to show selected option
            options[key - 1].parentElement.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
    }
    
    // Allow Enter key to submit form
    if (e.key === 'Enter') {
        const form = document.getElementById('quizForm');
        if (form) {
            form.submit();
        }
    }
});
