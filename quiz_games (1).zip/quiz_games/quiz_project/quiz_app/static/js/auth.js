/* ===================================
   AUTHENTICATION PAGES - JAVASCRIPT
   =================================== */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize form validation
    initializeFormValidation();
});

/* ===================================
   FORM VALIDATION
   =================================== */

/**
 * Initialize form validation and event listeners
 */
function initializeFormValidation() {
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');

    if (loginForm) {
        loginForm.addEventListener('submit', validateLoginForm);
    }

    if (signupForm) {
        signupForm.addEventListener('submit', validateSignupForm);
    }
}

/**
 * Validate login form before submission
 * @param {Event} e - Form submit event
 */
function validateLoginForm(e) {
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();

    // Basic validation
    if (!email) {
        e.preventDefault();
        showFieldError('email', 'Email is required');
        return false;
    }

    if (!isValidEmail(email)) {
        e.preventDefault();
        showFieldError('email', 'Please enter a valid email');
        return false;
    }

    if (!password) {
        e.preventDefault();
        showFieldError('password', 'Password is required');
        return false;
    }

    if (password.length < 6) {
        e.preventDefault();
        showFieldError('password', 'Password must be at least 6 characters');
        return false;
    }

    return true;
}

/**
 * Validate signup form before submission
 * @param {Event} e - Form submit event
 */
function validateSignupForm(e) {
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();
    const confirmPassword = document.getElementById('confirm_password').value.trim();

    // Validate name
    if (!name) {
        e.preventDefault();
        showFieldError('name', 'Full name is required');
        return false;
    }

    if (name.length < 3) {
        e.preventDefault();
        showFieldError('name', 'Name must be at least 3 characters');
        return false;
    }

    // Validate email
    if (!email) {
        e.preventDefault();
        showFieldError('email', 'Email is required');
        return false;
    }

    if (!isValidEmail(email)) {
        e.preventDefault();
        showFieldError('email', 'Please enter a valid email');
        return false;
    }

    // Validate password
    if (!password) {
        e.preventDefault();
        showFieldError('password', 'Password is required');
        return false;
    }

    if (password.length < 8) {
        e.preventDefault();
        showFieldError('password', 'Password must be at least 8 characters');
        return false;
    }

    // Check password strength (optional)
    if (!isStrongPassword(password)) {
        e.preventDefault();
        showFieldError('password', 'Password should contain uppercase, lowercase, and numbers');
        return false;
    }

    // Validate confirm password
    if (!confirmPassword) {
        e.preventDefault();
        showFieldError('confirm_password', 'Please confirm your password');
        return false;
    }

    if (password !== confirmPassword) {
        e.preventDefault();
        showFieldError('confirm_password', 'Passwords do not match');
        return false;
    }

    return true;
}

/* ===================================
   VALIDATION UTILITIES
   =================================== */

/**
 * Check if email format is valid
 * @param {string} email - Email to validate
 * @returns {boolean} - True if valid email format
 */
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

/**
 * Check if password is strong (contains uppercase, lowercase, number)
 * @param {string} password - Password to check
 * @returns {boolean} - True if password is strong
 */
function isStrongPassword(password) {
    const hasUppercase = /[A-Z]/.test(password);
    const hasLowercase = /[a-z]/.test(password);
    const hasNumber = /[0-9]/.test(password);
    
    return hasUppercase && hasLowercase && hasNumber;
}

/**
 * Display error message below a form field
 * @param {string} fieldId - ID of the form field
 * @param {string} message - Error message to display
 */
function showFieldError(fieldId, message) {
    const field = document.getElementById(fieldId);
    const existingError = field.parentElement.querySelector('.form-error');

    // Remove existing error if present
    if (existingError) {
        existingError.remove();
    }

    // Create error element
    const errorEl = document.createElement('span');
    errorEl.className = 'form-error';
    errorEl.textContent = message;

    // Add error below field
    field.parentElement.appendChild(errorEl);

    // Highlight field
    field.style.borderColor = '#e74c3c';
    field.focus();

    // Remove error on focus
    field.addEventListener('focus', function() {
        field.style.borderColor = '#e0e0e0';
        if (existingError) {
            existingError.remove();
        }
    });
}

/* ===================================
   REAL-TIME VALIDATION
   =================================== */

/**
 * Add real-time validation feedback to inputs
 */
document.addEventListener('DOMContentLoaded', function() {
    const emailInputs = document.querySelectorAll('input[type="email"]');
    const passwordInputs = document.querySelectorAll('input[type="password"]');

    // Email validation on blur
    emailInputs.forEach(input => {
        input.addEventListener('blur', function() {
            const email = this.value.trim();
            if (email && !isValidEmail(email)) {
                this.style.borderColor = '#e74c3c';
            } else {
                this.style.borderColor = '#e0e0e0';
            }
        });

        input.addEventListener('focus', function() {
            this.style.borderColor = '#667eea';
        });
    });

    // Password confirmation check
    const confirmPasswordInput = document.getElementById('confirm_password');
    if (confirmPasswordInput) {
        confirmPasswordInput.addEventListener('input', function() {
            const password = document.getElementById('password').value;
            const confirmPassword = this.value;

            if (confirmPassword && password && password !== confirmPassword) {
                this.style.borderColor = '#e74c3c';
            } else if (confirmPassword && password === confirmPassword) {
                this.style.borderColor = '#27ae60';
            } else {
                this.style.borderColor = '#e0e0e0';
            }
        });
    }
});
