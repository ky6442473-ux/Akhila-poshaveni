from django.contrib import admin
from .models import Quiz, Question, QuizSession, Answer


@admin.register(Quiz)
class QuizAdmin(admin.ModelAdmin):
    list_display = ['title', 'created_at']
    search_fields = ['title']


@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ['question_text', 'quiz', 'correct_option']
    list_filter = ['quiz']
    search_fields = ['question_text']
    fieldsets = (
        ('Question', {
            'fields': ('quiz', 'question_text')
        }),
        ('Options', {
            'fields': ('option_a', 'option_b', 'option_c', 'option_d')
        }),
        ('Correct Answer', {
            'fields': ('correct_option',)
        }),
    )


@admin.register(QuizSession)
class QuizSessionAdmin(admin.ModelAdmin):
    list_display = ['quiz', 'session_key', 'score', 'total_questions', 'started_at', 'completed_at']
    list_filter = ['quiz', 'started_at']
    search_fields = ['session_key']
    readonly_fields = ['started_at', 'completed_at']


@admin.register(Answer)
class AnswerAdmin(admin.ModelAdmin):
    list_display = ['session', 'question', 'selected_option', 'is_correct', 'answered_at']
    list_filter = ['is_correct', 'answered_at']
    search_fields = ['session__session_key']
    readonly_fields = ['answered_at']
