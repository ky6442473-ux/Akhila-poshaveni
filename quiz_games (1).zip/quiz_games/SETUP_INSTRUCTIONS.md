# Quiz Game Setup Instructions

## Step 1: Run Migrations
After creating the models, you need to create the database tables:

```powershell
python manage.py makemigrations
python manage.py migrate
```

## Step 2: Create Admin User (Optional)
To access the Django admin panel and add quiz questions:

```powershell
python manage.py createsuperuser
```

Then go to: `http://localhost:8000/admin/`

## Step 3: Add Quiz Data
You can add quizzes and questions through:
1. **Django Admin Panel** - http://localhost:8000/admin/
   - Add a Quiz
   - Add Questions (with options A, B, C, D and correct answer)

2. **Or programmatically** - Create a script to populate sample data

## Step 4: Run Server
```powershell
python manage.py runserver
```

Access the quiz at: `http://localhost:8000/`

---

## URL Routes

| Route | View | Purpose |
|-------|------|---------|
| `/` | home | Home page with Start button |
| `/start/` | start_quiz | Initialize new quiz session |
| `/quiz/` | quiz | Display current question |
| `/result/` | result | Show quiz results |
| `/clear/` | clear_session | Clear session and return to home |
| `/admin/` | admin | Django admin panel |

---

## How the Quiz Works

1. **Home Page** - User clicks "Start Quiz"
2. **Start Quiz** - Creates a new QuizSession, randomizes questions, stores in session
3. **Quiz Page** - Displays one question at a time with options (A, B, C, D)
4. **Answer Processing** - Saves answer, checks correctness, updates score
5. **Result Page** - Shows final score and feedback message
6. **Play Again** - Clears session and returns to home

---

## Models Overview

### Quiz
- `title` - Quiz name
- `description` - Quiz description
- `created_at` - Creation timestamp

### Question
- `quiz` - Foreign key to Quiz
- `question_text` - The question
- `option_a, b, c, d` - Four answer options
- `correct_option` - Which option is correct (A/B/C/D)

### QuizSession
- `quiz` - Which quiz is being taken
- `session_key` - Django session identifier
- `score` - Number of correct answers
- `total_questions` - Total questions in quiz
- `started_at`, `completed_at` - Timestamps

### Answer
- `session` - Which session this answer belongs to
- `question` - Which question was answered
- `selected_option` - What the user selected
- `is_correct` - Whether it was correct

---

## Sample Quiz Data (SQL/Admin)

Add a quiz through admin:
- Title: "General Knowledge Quiz"
- Description: "Test your knowledge"

Add questions with options:
- Question: "What is 2 + 2?"
  - A: "3"
  - B: "4" ✓ (correct)
  - C: "5"
  - D: "6"
